import emoji

print(emoji.emojize('Water! :water_wave:'))
print(
    emoji.demojize(
        ' at runtime expect NOT to see a picture here, but regular text instead -->    🌊'
    )
)
print(emoji.demojize('🌊'))
